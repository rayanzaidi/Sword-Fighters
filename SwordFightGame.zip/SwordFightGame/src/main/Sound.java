package main;

import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Sound {
	Clip clip;
	//created an array that stores sound files and plays them depending on what action is being performed.
	
	URL SoundFXURL[] = new URL[10];
	public Sound() {
		SoundFXURL[0] = getClass().getResource("/Sound/OptionsSelection.wav");
		SoundFXURL[1] = getClass().getResource("/Sound/EnterSelection.wav");
	}
	public void getSoundFile(int i) {
		try {
			AudioInputStream input = AudioSystem.getAudioInputStream(SoundFXURL[i]);
			clip = AudioSystem.getClip();
			clip.open(input);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void playSound() {
		clip.start();
	}
	public void loopSound() {
		clip.loop(Clip.LOOP_CONTINUOUSLY);
	}
	public void endFX() {
		clip.stop();
	}
}
