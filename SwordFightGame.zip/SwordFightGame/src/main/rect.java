package main;

import java.awt.Rectangle;

public class rect {
//rectangles to put around our character sprites to give them a hitbox and to detect a collision between them
	//This of course will be transparent meaning you will not be able to see it in game.
	//But this is going to create the mechanic of the hitboxes in the game
	int x, y;
	
	boolean right = false;
	
	public rect(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public Rectangle bounds() {
		
		return(new Rectangle(x,y,50,50));
		
	}
	public Rectangle setBounds() {
		return (new Rectangle(x,y,100,100));
	}
	
	
}


