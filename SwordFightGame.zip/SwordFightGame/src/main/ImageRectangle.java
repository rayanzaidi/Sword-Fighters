package main;

import java.awt.Image;
import java.awt.Rectangle;

public class ImageRectangle {

    public final Image image;

    public Rectangle rectangle;

    public ImageRectangle(Image image, Rectangle rectangle) {
        this.image = image;
        this.rectangle = rectangle;
    }

    public Rectangle getRectangle() {
        return rectangle;
    }

    public void setRectangle(Rectangle rectangle) {
        this.rectangle = rectangle;
    }

    public Image getImage() {
        return image;
    }

}