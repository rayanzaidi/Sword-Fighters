package main;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class InputHandler implements KeyListener {
	public static  boolean rightkey,leftkey, attackkey;
	
	GamePanel panel;
	UI ui;
	public static boolean leftkey2,rightkey2, attackkey2;
	public static boolean player1charge, player2charge;
	
	public InputHandler(GamePanel panel){
		this.panel = panel;
	}
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		//The game is going to start at the menu, So we need to make these conditions to make sure that
		//the indicator which is our int variable options selection doesn't go out of reach from the amount
		//of options are on the screen and also make a key event where you press enter, 
		if(panel.gameState == panel.menuState) {
			
			if(e.getKeyCode() == e.VK_D) {
				panel.ui.homeSelection++;
				if(panel.ui.homeSelection > 2) {
					panel.ui.homeSelection = 0;
				}
				panel.playSoundFX(0);
				}
			if(e.getKeyCode() == e.VK_A) {
				panel.ui.homeSelection--;
				if(panel.ui.homeSelection < 0) {
					panel.ui.homeSelection = 2;
					
				}
				panel.playSoundFX(0);
			
			
			}
			if(e.getKeyCode() == e.VK_ENTER) {
				if(panel.ui.homeSelection == 0) {
					panel.gameState = panel.playState;
					panel.playSoundFX(1);
				}
				if(panel.ui.homeSelection == 1) {
					System.exit(0);
				}
				
			}
		}
		if(panel.gameState == panel.playState) {
		//player 1 controls
		//keys A and D are to move left and right
		//the W key is to initiate an attack key
		
		if(e.getKeyCode() == e.VK_D) {
			rightkey = true;
		}
		if(e.getKeyCode() == e.VK_A) {
			leftkey = true;
		}
		if(e.getKeyCode() == e.VK_W) {
			attackkey = true;
			
		}
		//player 2 controls
		if(e.getKeyCode() == e.VK_RIGHT) {
			rightkey2 = true;
		}
		if(e.getKeyCode() == e.VK_LEFT) {
			leftkey2 = true;
		}
		if(e.getKeyCode() == e.VK_UP) {
			attackkey2 = true;
		}
		
		//pause button being implemented in game
		if(e.getKeyCode() == e.VK_P) {
			if(panel.gameState == panel.playState) {
				panel.gameState = panel.pauseState;
			}
			else if(panel.gameState == panel.pauseState) {
				panel.gameState = panel.playState;
			}
		}
		}
		}
		
		
	
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		//player 2 controls
		//The arrow keys: left and right are to move 
		//The up arrow key is to initiate an attack sequence.
	
		if(e.getKeyCode() == e.VK_RIGHT) {
			rightkey2 = false;
		}
		if(e.getKeyCode() == e.VK_LEFT) {
			leftkey2 = false;
		}
		if(e.getKeyCode() == e.VK_UP) {
			attackkey2 = false;
			
		}
		//player 1 controls
		if(e.getKeyCode() == e.VK_D) {
			rightkey = false;
		}
		if(e.getKeyCode() == e.VK_A) {
			leftkey = false;
		}
		if( e.getKeyCode() == e.VK_W) {
			attackkey = false;
			
		}
		}
		
		

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		//We are not gonna be needing this part of the KeyEvent program because we aren't
		//recording anything that is being typed into the program. We are only executing inputs.
	}
}