package main;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class InputHandler implements KeyListener {
	public static  boolean rightkey,leftkey, attackkey;
	
	GamePanel panel;
	UI ui;
	public static boolean leftkey2,rightkey2, attackkey2;
	public static boolean player1charge, player2charge;
	
	public InputHandler(GamePanel panel){
		this.panel = panel;
	}
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		//The game is going to start at the menu, So we need to make these conditions to make sure that
		//the indicator which is our int variable options selection doesn't go out of reach from the amount
		//of options are on the screen and also make a key event where you press enter, 
		if(panel.gameState == panel.menuState) {
			
			if(e.getKeyCode() == KeyEvent.VK_D) {
				panel.ui.homeSelection++;
				if(panel.ui.homeSelection > 3) {
					panel.ui.homeSelection = 0;
				}
				panel.playSoundFX(0);
				}
			if(e.getKeyCode() == KeyEvent.VK_A) {
				panel.ui.homeSelection--;
				if(panel.ui.homeSelection < 0) {
					panel.ui.homeSelection = 3;
					
				}
				panel.playSoundFX(0);
			
			
			}
			if(e.getKeyCode() == KeyEvent.VK_S) {
				if(panel.ui.homeSelection == 0 || panel.ui.homeSelection == 2) {
					//do nothing
				}
				else {
					panel.ui.homeSelection = 3;
					panel.playSoundFX(0);
				}
				
			}
			if(e.getKeyCode() == KeyEvent.VK_W) {
				if(panel.ui.homeSelection == 0 || panel.ui.homeSelection == 2) {
					//do nothing
				}
				else {
					panel.ui.homeSelection = 1;
					panel.playSoundFX(0);
				}
				
			}
			if(e.getKeyCode() == KeyEvent.VK_ENTER) {
				if(panel.ui.homeSelection == 0) {
					panel.gameState = panel.playState;
					panel.playSoundFX(1);
				}
				if(panel.ui.homeSelection == 1) {
					System.exit(0);
				}
				if(panel.ui.homeSelection == 2) {
					panel.gameState = panel.optionsState;
					panel.playSoundFX(1);
					//Work on this later
				}
				if(panel.ui.homeSelection == 3) {
					panel.gameState = panel.howtoplayState;
					panel.playSoundFX(1);
				}
				
			}
			
			
		}
		if(panel.gameState == panel.optionsState) {
			if(e.getKeyCode() == KeyEvent.VK_S) {
				panel.ui.optionsSelection++;
				if(panel.ui.optionsSelection > 3) {
					panel.ui.optionsSelection = 0;
				}
				
				
			}
			if(e.getKeyCode() == KeyEvent.VK_W) {
				panel.ui.optionsSelection--;
				if(panel.ui.optionsSelection < 0) {
					panel.ui.optionsSelection = 3;
				}
			}
			if(e.getKeyCode() == KeyEvent.VK_ENTER) {
				if(panel.ui.optionsSelection == 0) {
					if(panel.ui.SoundOn == true) {
						panel.ui.SoundOn = false;
					}
					if(panel.ui.SoundOn = false) {
						panel.ui.SoundOn = true;
					}
				}
				if(panel.ui.optionsSelection == 3) {
					panel.gameState = panel.menuState;
					panel.ui.optionsSelection = 0;
				}
			}
			
		}
		
		
		
		if(panel.gameState == panel.playState) {
		//player 1 controls
		//keys A and D are to move left and right
		//the W key is to initiate an attack key
		
		if(e.getKeyCode() == KeyEvent.VK_D) {
			rightkey = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_A) {
			leftkey = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_W) {
			attackkey = true;
			
		}
		//player 2 controls
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
			rightkey2 = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT) {
			leftkey2 = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_UP) {
			attackkey2 = true;
		}
		
		//pause button being implemented in game
		if(e.getKeyCode() == KeyEvent.VK_P) {
			if(panel.gameState == panel.playState) {
				panel.gameState = panel.pauseState;
			}
			else if(panel.gameState == panel.pauseState) {
				panel.gameState = panel.playState;
			}
		}
		}
		}
		
		
	
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		//player 2 controls
		//The arrow keys: left and right are to move 
		//The up arrow key is to initiate an attack sequence.
	
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
			rightkey2 = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT) {
			leftkey2 = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_UP) {
			attackkey2 = false;
			
		}
		//player 1 controls
		if(e.getKeyCode() == KeyEvent.VK_D) {
			rightkey = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_A) {
			leftkey = false;
		}
		if( e.getKeyCode() == KeyEvent.VK_W) {
			attackkey = false;
			
		}
		}
		
		

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		//We are not gonna be needing this part of the KeyEvent program because we aren't
		//recording anything that is being typed into the program. We are only executing inputs.
	}
}