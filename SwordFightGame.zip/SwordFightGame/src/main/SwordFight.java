package main;
import java.util.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class SwordFight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GameFrame();
	}

}
