package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class Health {
	GamePanel panel;
	Swordsmen player;
	BufferedImage full_heart, half_heart, heart_blank, half_heart2, full_heart2;
	public double player1hp = 8;
	public double player2hp = 8;
	public static int roundcount = 0;
	public static int player1score = 0;
	public static int player2score = 0;
	boolean played = false;
	Sound sound;
	public Health(GamePanel panel){
		this.panel = panel;
		getHeartImage();
	}
	public void getHeartImage() {
		try {
			heart_blank = ImageIO.read(getClass().getResourceAsStream("/Health/Health_blank.png"));
			full_heart = ImageIO.read(getClass().getResourceAsStream("/Health/Health_full.png"));
			half_heart = ImageIO.read(getClass().getResourceAsStream("/Health/Health_half.png"));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void update() {
		panel.hitBoxesandAttack();
			if(player1hp <= 0 && player2hp > 0) {
				player2score++;
				panel.newRound();
			}
		    if(player2hp <= 0 && player1hp > 0) {
				player1score++;
				
				played = true;
				panel.newRound();
				if(played == true) {
					
				}
			}
			if(player1hp <= 0 && player2hp <= 0) {
				
				played = true;
				panel.newRound();
				if(played == true) {
					
					played = false;
				}
			}
			if(player1score == 10) {
				
			}
			if(player2score == 10) {
				
			}
		}
	
	
	public void draw(Graphics2D g2) {
		//cords for heart images for player 1
		int player1HealthX = 100;
		int player1HealthY = 50;
		int i = 0;
		int player2HealthX = 675;
		int player2HealthY = 50;
		int j = 0;
		
		//if the player gets hit, reset their life by resetting the values and creating
		//a while loop.
		
		while(i < player1hp) {
			g2.drawImage(half_heart, player1HealthX,player1HealthY,50,50,null);
			i++;
			if(i < player1hp) {
				g2.drawImage(full_heart, player1HealthX, player1HealthY,50,50,null);
			}
			i++;
			player1HealthX = player1HealthX + 50;
			
		}

		while(j < player2hp) {
			g2.drawImage(half_heart, player2HealthX,player2HealthY,50,50,null);
			j++;
			if(j < player2hp) {
				g2.drawImage(full_heart, player2HealthX, player2HealthY,50,50,null);
			}
			j++;
			player2HealthX = player2HealthX + 50;
		}
		
		
		//This is going to display the score for each player and if that player gets 3 points they win the game against the 
		//opposing player.
		int x1 = 400;
		int y1 = 100;
		int x2 = 550;
		int y2 = 100;
		g2.setColor(Color.white);
		g2.setFont(new Font("Dialog",Font.BOLD,60));
		g2.drawString(""+player1score, x1, y1);
		g2.drawString(""+player2score, x2, y2);
		if(player1score == 10) {
			
		}
		if(player2score == 10) {
			
		}
		
	}

	}

	
	

