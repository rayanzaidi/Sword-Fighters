package main;
import java.util.*;

import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.awt.*;

import javax.imageio.ImageIO;
import javax.swing.*;


public class ItemDrop extends Rectangle {
	GamePanel panel;
	static BufferedImage myShield;
	BufferedImage image;
	public int x;
	public int y;
	public int width;
	public int height;
	public boolean Shieldplayer1, Shieldplayer2;
	public int rectx, recty, rectwidth, rectheight;
	Rectangle rectangle;
	ItemDrop(GamePanel panel){
		this.panel = panel;
		newItem();
		
	}
	
	public void newItem() {
		getItemImage();
		setDefaultValues();
		
	}
	public void getItemImage() {
		try {
			myShield = ImageIO.read(getClass().getResourceAsStream("/Items/Shield.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void setDefaultValues() {
		x = ((int)((Math.random()*panel.GAME_WIDTH-200)+200));
		y = 475;
		width = 200;
		height = 200;
		rectx = x+23;
		recty = 500;
		rectwidth = 47; 
		rectheight = 45;
	}
	public void update() {
		checkCollision();
	}
	
	public void checkCollision() {
	if(Shieldplayer1 == true) {	
		image = null;
		
	}
	if(panel.collision == true && Shieldplayer2 == true) {
		image = null;
	}
	
	}
	
	public void draw(Graphics2D g2) {
		checkCollision();
		image = null;
		if(Shieldplayer1 == true || Shieldplayer2 == true) {
			g2.drawImage(image,x, y, 200,200, null);
			
		}
		else {
			image = myShield;
			g2.drawImage(image, x, y, 100,100,null);
		}
		
	
		
		
		
	}
}
