package main;
import java.util.*;

import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.awt.*;

import javax.imageio.ImageIO;
import javax.swing.*;


public class ItemDrop extends Rectangle {
	GamePanel panel;
	 public BufferedImage myShield, fireSword, medKit;
	 public static BufferedImage myShield2;
	public Image image;
	public int x;
	public int y;
	public int width;
	public int height;
	public int randomizer;
	public boolean Shieldplayer1, Shieldplayer2;
	public int rectx, recty, rectwidth, rectheight;
	Rectangle rectangle;
	
	Random random = new Random();
	ItemDrop(GamePanel panel){
		this.panel = panel;
		getItemImage();
		setDefaultValues();
		
	}
	
	
	
	public void getItemImage() {
		try {
			myShield = ImageIO.read(getClass().getResourceAsStream("/Items/Shield.png"));
			fireSword = ImageIO.read(getClass().getResourceAsStream("/Items/firesword1.png"));
			medKit = ImageIO.read(getClass().getResourceAsStream("/Items/Medkit.png"));
			
			//This is for title screen lol
			myShield2 = ImageIO.read(getClass().getResourceAsStream("/Items/Shield.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void setDefaultValues() {
		rectx = 500;
		recty = 450;
		rectwidth = 100;
		rectheight = 100;
	}
	public void draw(Graphics2D g2) {
		g2.drawImage(fireSword,rectx,recty,rectwidth,rectheight,null);
		if(panel.itemcollision == true) {
			fireSword = null;
		}
		
}

}