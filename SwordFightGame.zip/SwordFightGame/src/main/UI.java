package main;
import java.util.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.*;
import javax.swing.*;
public class UI {
	GamePanel panel;
	Graphics2D g2;
	Menu menu;
	public int homeSelection = 0;
	UI(GamePanel panel){
		this.panel = panel;
	}
	//These are made for each part of the game's screens. Like for example a title screen and pause screen.
	//We implement these by adding int variables that determine the state of the game. 
	public void draw(Graphics2D g2) {
		this.g2 = g2;
		g2.setColor(Color.green);
		if(panel.gameState == panel.pauseState) {
			drawPauseScreen();
		}
		if(panel.gameState == panel.menuState) {
			drawMenuScreen();
		}
		
		
	}
	public void drawPauseScreen() {
		String text = "PAUSED";
		String text2 = "Press Esc To Go To Game Menu";
		int x = getTextCenterofScreen(text);
		int y = panel.GAME_HEIGHT/2;
		g2.setFont(new Font("Sans Serif", Font.BOLD,60));
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		
		g2.setFont(new Font("Sans Serif", Font.BOLD,40));
		y = y + 100;
		x = 200;
		g2.drawString(text2, x, y);
		
	}
	public void drawMenuScreen() {
		//Options & title
		String text = "Sword Fighters";
		String text2 = "Play";
		String text3 = "Options";
		String text4 = "Quit";
		//Position for each of the string when drawn
		int x = 275;
		int y = 100;
		
		//Drawing Title String
		g2.setFont(new Font("Sans Serif",Font.BOLD,60));
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		//Drawing image 
		y = 0;
		g2.drawImage(ItemDrop.myShield, x, y, 500, 500, null);
		
		//Drawing options selection 
		x = 200;
		y = 500;
		g2.setFont(new Font("Sans Serif",Font.BOLD,40));
		g2.drawString(text2, x, y);
		if(homeSelection == 0) {
			g2.setColor(Color.red);
			g2.drawString(">", x-50, y);
		}
		
		x = 465;
		g2.setColor(Color.white);
		g2.drawString(text4, x, y);
		if(homeSelection == 1) {
			g2.setColor(Color.red);
			g2.drawString(">", x-50,y);
		}
		
		x = 700;
		g2.setColor(Color.white);
		g2.drawString(text3, x, y);
		if(homeSelection == 2) {
			g2.setColor(Color.red);
			g2.drawString(">", x-50, y);
		}
	}
	public void drawOptionsScreen() {
		
	}
	
	public int getTextCenterofScreen(String text) {
		//Author RyiSnow for this life changing method
		int length = (int)g2.getFontMetrics().getStringBounds(text,g2).getWidth();
		int x = GamePanel.GAME_WIDTH/2 - length/2;
		return x;
	}
}
