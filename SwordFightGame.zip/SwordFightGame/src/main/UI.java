package main;
import java.util.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.*;
import javax.swing.*;
public class UI {
	GamePanel panel;
	Graphics2D g2;
	Menu menu;
	public int homeSelection = 0;
	public int optionsSelection = 0;
	public int instructionSelection = 0;
	
	public boolean SoundOn = true;
	UI(GamePanel panel){
		this.panel = panel;
	} 
	/*
	 * This class draws the user Interfaces such as the game menu and option screen
	 * You had to pass the panel into the class and give it the Graphics for it to draw these UIS into the game
	 */
	public void draw(Graphics2D g2) {
		this.g2 = g2;
		g2.setColor(Color.green);
		if(panel.gameState == panel.pauseState) {
			drawPauseScreen();
		}
		if(panel.gameState == panel.menuState) {
			drawMenuScreen();
		}
		if(panel.gameState == panel.optionsState) {
			drawOptionsScreen();
		}
		if(panel.gameState == panel.howtoplayState) {
			drawInstructionScreen();
		}
		if(panel.gameState == panel.mapSelectionState) {
			drawMapSelectionScreen();
		}
				
		
		
	}
	public void drawPauseScreen() {
		String text = "PAUSED";
		String text2 = "Press Esc To Go To Game Menu";
		int x = getTextCenterofScreen(text);
		int y = panel.GAME_HEIGHT/2;
		g2.setFont(new Font("Sans Serif", Font.BOLD,60));
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		
		g2.setFont(new Font("Sans Serif", Font.BOLD,40));
		y = y + 100;
		x = 200;
		g2.drawString(text2, x, y);
		
	}
	public void drawMenuScreen() {
		//Options & title
		String text = "Sword Fighters";
		String text2 = "Play";
		String text3 = "Options";
		String text4 = "Quit";
		String text5 = "How to Play";
		//Position for each of the string when drawn
		int x = 275;
		int y = 100;
		
		//Drawing Title String
		g2.setFont(new Font("Sans Serif",Font.BOLD,60));
		g2.setColor(Color.white);
		g2.drawString(text, x, y);
		//Drawing image 
		y = 0;
		g2.drawImage(ItemDrop.myShield2, x, y, 500, 500, null);
		
		//Drawing options selection 
		x = 200;
		y = 500;
		g2.setFont(new Font("Sans Serif",Font.BOLD,40));
		g2.drawString(text2, x, y);
		if(homeSelection == 0) {
			g2.setColor(Color.red);
			g2.drawString(">", x-50, y);
		}
		
		x = 465;
		g2.setColor(Color.white);
		g2.drawString(text4, x, y);
		if(homeSelection == 1) {
			g2.setColor(Color.red);
			g2.drawString(">", x-50,y);
		}
		
		x = 700;
		g2.setColor(Color.white);
		g2.drawString(text3, x, y);
		if(homeSelection == 2) {
			g2.setColor(Color.red);
			g2.drawString(">", x-50, y);
		}
		x = 400;
		y = 575;
		g2.setColor(Color.white);
		g2.drawString(text5, x, y);
		if(homeSelection == 3) {
			g2.setColor(Color.red);
			g2.drawString(">", x-50, y);
		}
	}
	public void drawOptionsScreen() {
		g2.setColor(Color.white);
	
		g2.setFont(new Font("Sans Serif", Font.BOLD,40));
		
		String text = "Options";
		int x = getTextCenterofScreen(text);
		int y = 100;
		g2.drawString(text,x,y);
		
		x = 100;
		y = 200;
		g2.drawString("Sound Effects:",x,y);
		String optionStatus1 = "ON";
		g2.drawString(optionStatus1,x+400,y);
		if(SoundOn == true) {
			optionStatus1 = "OFF";
			g2.drawString(optionStatus1,x+400,y);
			
		}
		
		
		if(optionsSelection == 0) {
			g2.setColor(Color.cyan);
			g2.drawString(">", x + 350, y);
			g2.setColor(Color.white);
		}
		
		String text2 = "Music:";
		x = 200;
		y = 300;
		g2.drawString(text2, x, y);
		g2.drawString("ON", x+300, y);
		if(optionsSelection == 1) {
			g2.setColor(Color.cyan);
			g2.drawString(">", x + 250, y);
			g2.setColor(Color.white);
		}
		
		//being added
		String text3 = "Item Drops:";
		x = 150;
		y = 400;
		g2.drawString(text3, x, y);
		g2.drawString("ON", x+350, y);
		if(optionsSelection == 2) {
			g2.setColor(Color.cyan);
			g2.drawString(">", x+300, y);
			g2.setColor(Color.white);
		}
		
		
		String text4 = "Back";
		x = getTextCenterofScreen(text4);
		y = 550;
		g2.drawString(text4, x, y);
		if(optionsSelection == 3) {
			g2.setColor(Color.cyan);
			g2.drawString(">", x - 50, y);
			g2.setColor(Color.white);
		}
	}
	public void drawInstructionScreen() {
		g2.setFont(new Font("Sans Serif", Font.BOLD,45));
		g2.setColor(Color.white);
		String text = "Instructions";
		int x = getTextCenterofScreen(text);
		int y = 100;
		g2.drawString(text, x, y);
		
		g2.setFont(new Font("Sans Serif", Font.BOLD,25));
		text = "This game is a multiplayer game and the goal in this game is to defeat";
		x = 50;
		y = 200;
		g2.drawString(text,x,y);
		
		text = "the enemy player.";
		y = 250;
		g2.drawString(text, x, y);
		
		//Displaying player 1 controls
		g2.setColor(Color.blue);
		text = "Player 1 Controls:";
		y = 300;
		g2.drawString(text, x, y);
		
		g2.setColor(Color.white);
		text = "Hold W = Attack";
		y = 350;
		g2.drawString(text, x, y);
		
		text = "D = Forward";
		y = 400;
		g2.drawString(text, x, y);
		
		text = "A = Back";
		y = 450;
		g2.drawString(text, x, y);
		
		g2.setColor(Color.red);
		text = "Player 2 Controls:";
		x = 500;
		y = 300;
		g2.drawString(text, x, y);
		
		g2.setColor(Color.white);
		
		text = "Hold up arrow key (^) = Attack";
		y = 350;
		g2.drawString(text, x, y);
		
		text = "Left arrow key (<) = Forward";
		y = 400;
		g2.drawString(text, x, y);
		
		text = "Right arrow key (>) = Back";
		y = 450;
		g2.drawString(text, x, y);
		
		text = "Back";
		y = 550;
		x = getTextCenterofScreen(text)-50;
		g2.setFont(new Font("Sans Serif", Font.BOLD,45));
		g2.drawString(text,x,y);
		
		g2.setColor(Color.red);
		g2.drawString(">", x-50, y);
		
		
		
	}
	public void drawMapSelectionScreen() {
		
	}
	public int getTextCenterofScreen(String text) {
		//Author RyiSnow for this life changing method
		int length = (int)g2.getFontMetrics().getStringBounds(text,g2).getWidth();
		int x = GamePanel.GAME_WIDTH/2 - length/2;
		return x;
	}
}
