package main;
import java.util.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.awt.*;
import javax.imageio.ImageIO;
import javax.swing.*;

public class Swordsmen extends Rectangle {
	public int player1X;
	public int player1Y;
	public int playerSpeed;
	public int attackSpeed;
	public int playerchargeSpeed;
	public int spriteCounter = 0;
	public int spriteNum = 1;
	public int spriteNum2 = 1;
	public int spriteNum3 = 1;
	public int spriteNum4 = 1;
	public int spriteCounter3 = 0;
	public int spriteCounter4 = 0;
	public int spriteCounter2 = 0;
	public int player2X;
	public int player2Y;
	public int border = 1;
	public static int id;
	public BufferedImage forward1, forward2, idle, player2forward1, player2forward2, idle2, attack1, attack2,
	player2attack1, player2attack2, player1chargeidle,player1chargeattack, player1shieldedattack1, player1shieldedattack2,
	player2shieldedattack1, player2shieldedattack2;
	public String direction,direction2;
	InputHandler KeyHandler;
	GamePanel panel;
	
	

	public Swordsmen(GamePanel panel, InputHandler keys){
		this.panel = panel;
		this.KeyHandler = keys;
		
		defaultValues();
		getPlayerImage();
	}
	public void defaultValues() {
		player1X = 2;
		player1Y = 400;
		player2X = GamePanel.GAME_WIDTH-2;
		player2Y = 400;
		attackSpeed = 1;
		playerSpeed = 4;
		playerchargeSpeed = 7;
		direction = "right";
		direction2 = "left";
		
	}
	public void getPlayerImage() {
		try {
			forward1 = ImageIO.read(getClass().getResourceAsStream("/Player/BlueCharacter_moveright.png"));
			forward2 = ImageIO.read(getClass().getResourceAsStream("/Player/BlueCharacter-3.png.png"));
			idle = ImageIO.read(getClass().getResourceAsStream("/Player/BlueCharacter_moveright.png"));
			attack1 = ImageIO.read(getClass().getResourceAsStream("/Player/BlueCharacter_Attack1.png"));
			attack2 = ImageIO.read(getClass().getResourceAsStream("/Player/BlueCharacter_Attack2.png"));
			player2attack1 = ImageIO.read(getClass().getResourceAsStream("/Player/RedCharacter_Attack1.png"));
			player2attack2 = ImageIO.read(getClass().getResourceAsStream("/Player/RedCharacter_Attack2.png"));
			player2forward1 = ImageIO.read(getClass().getResourceAsStream("/PLayer/RedCharacter_moveright.png"));
			player2forward2 = ImageIO.read(getClass().getResourceAsStream("/Player/RedCharacter_moveright2.png"));
			idle2 = ImageIO.read(getClass().getResourceAsStream("/Player/RedCharacter_Idle.png"));
			
			
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	public void update() {
		
	//player 1 controls
	if(InputHandler.leftkey == true || InputHandler.rightkey == true || InputHandler.attackkey == true) {
	if(InputHandler.rightkey == true || InputHandler.player1charge == true) {
		if(InputHandler.rightkey == true) {
			direction = "right";
			player1X += playerSpeed;
		}
			
	}
	if(InputHandler.leftkey == true) {
		direction = "left";
		player1X -= playerSpeed;
		}
	
	if(InputHandler.attackkey == true) {
		direction = "up";
	}
	
	spriteCounter++;
	if(spriteCounter > 15) {
		if(spriteNum == 1) {
			spriteNum = 2;
		}
		else if(spriteNum == 2) {
			spriteNum = 1;
		}
		spriteCounter = 0;
	}
	}
	if(InputHandler.leftkey2 == true || InputHandler.rightkey2 == true || InputHandler.attackkey2 == true) {
		if(InputHandler.leftkey2 == true) {
			direction2 = "left";
			player2X -= playerSpeed;
		}
		if(InputHandler.rightkey2 == true) {
			direction2 = "right";
			player2X += playerSpeed;
		}
		if(InputHandler.attackkey2 == true) {
			direction2= "up";

		}
		spriteCounter2++;
		if(spriteCounter2 > 15) {
			if(spriteNum2 == 1) {
				spriteNum2 = 2;
			}
			else if(spriteNum2 == 2) {
				spriteNum2 = 1;
			}
			spriteCounter2 = 0;
		}
	}	
		}
	
	public void draw(Graphics2D g2) {
		
		BufferedImage image = null;
		BufferedImage image2 = null;
		if(direction.equals("right")) {
			if(spriteNum == 1) {
				image = forward1;
			}
			if(spriteNum == 2) {
				image = forward2;
			}
		}
		
		if(direction.equals("left")) {
			if(spriteNum == 1) {
				image = forward1;
			}
			if(spriteNum == 2) {
				image = forward2;
			}
		}
		
		if(direction.equals("up")) {
			if(spriteNum == 1) {
				image = attack1;
				;
			}
			if(spriteNum == 2) {
				image = attack2;
				
			}
			
		}
		
		
		if(direction2.equals("right")) {
			if(spriteNum2 == 1) {
				image2 = player2forward1;
			}
			if(spriteNum2 == 2) {
				image2 = player2forward2;
			}
		}
		
		 if(direction2.equals("left")) {
			if(spriteNum2 == 1) {
				image2 = player2forward1;
			}
			if(spriteNum2 == 2) {
				image2 = player2forward2;
			}
		}
		 
		 if(direction2.equals("up")) {
				if(spriteNum2 == 1) {
					image2 = player2attack1;
					
				}
				if(spriteNum2 == 2) {
					image2 = player2attack2;
					
					direction = "left";
				}
				
			}
		
		g2.drawImage(image, player1X, player1Y, panel.PLAYER_SIZE,panel.PLAYER_SIZE, null);
		g2.drawImage(image2,player2X, player2Y, panel.PLAYER_SIZE,panel.PLAYER_SIZE, null);
		
	}
	}

