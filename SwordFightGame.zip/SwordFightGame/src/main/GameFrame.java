package main;
import java.util.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class GameFrame extends JFrame {

	JFrame frame;
	
	GameFrame(){
		frame = new JFrame();
		this.add(new GamePanel());
		this.setResizable(false);
		this.setTitle("Sword Fighters");
		this.setBackground(Color.black);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.pack();
		this.setVisible(true);
	}
}
