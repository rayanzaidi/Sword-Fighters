package main;
import java.util.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.awt.*;

import javax.imageio.ImageIO;
import javax.swing.*;
public class GamePanel extends JPanel implements Runnable {
	JPanel panel;
	public final int PLAYER_SIZE = 150;
	public static final int GAME_WIDTH = 1000;
	public static final int GAME_HEIGHT = 600;
	public static final Dimension SCREEN_SIZE = new Dimension(GAME_WIDTH, GAME_HEIGHT);
	public int gameState;
	public final int pauseState = 1;
	public final int playState = 2;
	public final int menuState = 3;
	public final int optionsState = 4;
	Thread gameThread;
	InputHandler KeyHandler = new InputHandler(this);
	int playerSpeed = 4;
	int noPlayerSpeed = 0;
	int FPS = 60;
	BufferedImage image;
	Swordsmen player;
	rect Itemrect2;
	rect rect1;
	rect rect2;
	rect itemRect;
	boolean collision = false;
	boolean itemcollision = false;
	Health health;
	public UI ui = new UI(this);
	ItemDrop item = new ItemDrop(this);
	Rectangle rectangle1;
	Rectangle rectangle2;
	Rectangle ItemRect;
	Sound soundfx = new Sound();
	
	GamePanel(){
		panel = new JPanel();
		this.setPreferredSize(SCREEN_SIZE);
		this.addKeyListener(KeyHandler);
		this.setFocusable(true);
		this.setBackground(Color.black);
		setupGame();
		
		
	}
	public void setupGame() {
		gameState = menuState;
		newSwordsmen();
		newHearts();
		newItem();
		startGameThread();
		
		
		
		
		
	}
	
	
	
	public void newSwordsmen() {
		 player = new Swordsmen(this,KeyHandler);
		
	}
	public void newHearts() {
		health = new Health(this);
	}
	public void newItem() {
		item = new ItemDrop(this);
	}
	public void continueorquit() {	
	}
	public void newRound() {
		newSwordsmen();
		newHearts();
		
	}
	public void checkCollision() {
		if(player.player1X <= 0) {
			player.player1X = 0;
		}
		if(player.player1X >= GAME_WIDTH - 150) {
			player.player1X = 850;
		}
		if(player.player2X <= 0) {
			player.player2X = 0;
		}
		if(player.player2X >= GAME_WIDTH - 150) {
			player.player2X = 850;
		}
		rect1 = new rect(player.player1X + 50, player.player1Y);
		rect2 = new rect(player.player2X + 50, player.player2Y);
		itemRect = new rect(item.x,item.y);
		
		rectangle1 = rect1.bounds();
		rectangle2 = rect2.bounds();
		ItemRect = itemRect.setBounds();
		if(rectangle1.intersects(ItemRect)) {
			item.Shieldplayer1 = true;
			item.checkCollision();
		}
		if(rectangle2.intersects(ItemRect)) {
			collision = true;
			item.Shieldplayer2 = true;
			item.checkCollision();
		}
		if(rectangle1.intersects(rectangle2)) {
			collision = true;
			hitBoxes();	
		} else {
			collision = false;
		}
	}
	public void hitBoxes() {
		if(collision == true && InputHandler.rightkey == true) {
			player.player1X = player.player1X - player.playerSpeed;
		}
		if(collision == true && InputHandler.leftkey2 == true) {
			player.player2X = player.player2X + player.playerSpeed;
		}
		//if player 1 swings at the second player using the attack key in hitbox range
		if(collision == true && InputHandler.attackkey == true) {
			hitBoxesandAttack();
		}
		if(collision == true && InputHandler.attackkey2 == true) {
			hitBoxesandAttack();
		}
		
		
	}
	public void hitBoxesandAttack() {
		if(collision == true && (InputHandler.attackkey == true)) {
			health.player2hp = health.player2hp - 0.015;
		}
		if(collision == true && InputHandler.attackkey2 == true) {
			health.player1hp = health.player1hp - 0.015;
		}
		
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
		if(gameState == menuState || gameState == optionsState) {
			ui.draw(g2);
		}
		else if(gameState == playState) {
			player.draw(g2);
			health.draw(g2);
			item.draw(g2);
			ui.draw(g2);	
			item.draw(g2);
		}
		
		
	}
	public void startGameThread() {
		gameThread = new Thread(this);
		gameThread.start();
	}
	@Override
	public void run() {
		//game loop for game.
		// TODO Auto-generated method stub
		//this method is what makes the game run.
		//it runs on a gameThread and it is a game loop to update, repaint and do what not
		//Whenever the game is running
		double drawInterval = 1000000000/FPS;
		double delta = 0;
		double drawTime = System.nanoTime();
		long currentTime;
		int drawCount = 0;
		long timer = 0;
		while(gameThread != null) {
			currentTime = System.nanoTime();
			delta += (currentTime - drawTime) /drawInterval;
			timer += (currentTime - drawTime);
			drawTime = currentTime;
			
			if(delta >= 1) {
				update();
				repaint();
				checkCollision();
				delta--;
				drawCount++;
			}
			if(timer >= 1000000000) {
				System.out.println("FPS:" + FPS);
				drawCount = 0;
				timer = 0;
			}	
		}
	}
	public void update() {
		if(gameState == playState) {
		player.update();
		health.update();
		item.update();
		}
		
	}
	public void soundMusic(int i) {
		soundfx.getSoundFile(i);
		soundfx.playSound();
		soundfx.loopSound();
	}
	public void stopFX() {
		soundfx.endFX();
	}
	public void playSoundFX(int i) {
		soundfx.getSoundFile(i);
		soundfx.playSound();
		
	}
	
}